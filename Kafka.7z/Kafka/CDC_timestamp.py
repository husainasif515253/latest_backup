import mysql.connector
from kafka import KafkaProducer

ts = 1551085361

while(True):
	producer = KafkaProducer(bootstrap_servers=['sandbox-hdp.hortonworks.com:6667'],value_serializer=lambda x:x.encode('utf-8'))
	cnx = mysql.connector.connect(user='root', password='root',host='localhost',database='husain')
	cursor = cnx.cursor()
	query = ("SELECT id,datee,timee,cogt,pt08s1co,c6h6gt,pt08s2nmhc,noxgt,pt08s3nox,no2gt,pt08s4no2,pt08s5o3,t_data,RH_data,AH_data,ts,UNIX_TIMESTAMP(ts2) FROM air2 where UNIX_TIMESTAMP(ts2) > "+str(ts))
	cursor.execute(query)
	for (id,datee,timee,cogt,pt08s1co,c6h6gt,pt08s2nmhc,noxgt,pt08s3nox,no2gt,pt08s4no2,pt08s5o3,t_data,RH_data,AH_data,ts,ts2) in cursor:
		content = str(id)+","+str(datee)+","+str(timee)+","+str(cogt)+","+str(pt08s1co)+","+str(c6h6gt)+","+str(pt08s2nmhc)+","+str(noxgt)+","+str(pt08s3nox)+","+str(no2gt)+","+str(pt08s4no2)+","+str(pt08s5o3)+","+str(t_data)+","+str(RH_data)+","+str(AH_data)+","+str(ts)
		producer.send('test', content)
		ts = ts2
