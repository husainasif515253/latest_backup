import MySQLdb
from kafka import KafkaProducer

ts = 1549435940
while(True):
    producer = KafkaProducer(bootstrap_servers=['sandbox-hdp.hortonworks.com:9092'],value_serializer=lambda x:x.encode('utf-8'))
    db = MySQLdb.connect("localhost","root","root","husain" )
    cursor = db.cursor()
    cursor.execute("SELECT InvoiceNo,StockCode,Description,Quantity,InvoiceDate,UnitPrice,CustomerID,Country, UNIX_TIMESTAMP(ts) FROM f1 where UNIX_TIMESTAMP(ts) > "+str(ts))
    data = cursor.fetchall()
    if(len(data) != 0):
            for i in range(len(data)):
                    content = str(data[i][0])+"#"+str(data[i][1])+"#"+str(data[i][2])+"#"+str(data[i][3])+"#"+str(data[i][4])+"#"+str(data[i][5])+"#"+str(data[i][6])+"#"+str(data[i][7])
                    producer.send('test', content)
                    ts = data[i][8]
    db.close()
    producer.close()