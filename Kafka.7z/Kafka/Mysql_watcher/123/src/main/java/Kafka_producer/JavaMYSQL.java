package Kafka_producer;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Date;
import java.util.Properties;

import org.apache.kafka.clients.producer.*;

class JavaMYSQL{
			Properties props = new Properties();
			
			static long ts = 1547794172;
			static TimerTask task = new TimerTask() {
				@Override
				public void run() {
					try{
						System.out.println(ts);
						Class.forName("com.mysql.jdbc.Driver");  
						Connection con=DriverManager.getConnection("jdbc:mysql://192.168.5.94:3306/husain","root","root");    
						Statement stmt=con.createStatement();  
						ResultSet rs=stmt.executeQuery("select * from nikaza_user_data_ts where UNIX_TIMESTAMP(timestamp) > "+ts);
						while(rs.next()) {  
							System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
							ts = rs.getTimestamp(14).getTime()/1000;
							
						}
						con.close();
					}catch(Exception e){ System.out.println(e);}
				}
			};
			
	public static void main(String args[]){
		
		Timer timer = new Timer();
		timer.schedule(task,  new Date(), 3000);
	}
}