package Kafka_producer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

public class MySQLProducer {
	static long ts = 1548243370;
	static Producer<String, String> producer = null;
	public static void main(String[]args) throws IOException, InterruptedException {
		String topic = "avl";
	    String key = "key32";
		InputStream input = null;
        Properties prop = new Properties();
		try {
			input = new FileInputStream("C:/Users/u21a49/Desktop/kafka_test/123/src/main/java/Kafka_producer/file.properties");
			prop.load(input);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		input.close();
		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				try{
					System.out.println(ts);
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://192.168.5.94:3306/husain","root","root");    
					Statement stmt=con.createStatement();  
					ResultSet rs=stmt.executeQuery("select * from ts where UNIX_TIMESTAMP(ts) > "+ts);
					while(rs.next()) {
						producer = new KafkaProducer<String, String>(prop);
						String content = rs.getString(1)+","+rs.getString(2)+","+rs.getString(4)+","+rs.getDouble(5)+","+rs.getDouble(6)+","+rs.getString(7)+","+rs.getString(9)+","+rs.getString(10)+","+rs.getString(13);
						System.out.println(content);
						producer.send(new ProducerRecord<String, String>(topic, key, content));
						ts = rs.getTimestamp(14).getTime()/1000;
					}
					con.close();
				}catch(Exception e){ System.out.println(e);}
			}
		};
		Timer timer = new Timer();
		timer.schedule(task,  new Date(), 3);
	}
}