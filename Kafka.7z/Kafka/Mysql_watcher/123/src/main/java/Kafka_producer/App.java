package Kafka_producer;

import java.util.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPInputStream;

import org.apache.kafka.clients.producer.*;

class App{
	public static void main(String[]args) throws IOException, InterruptedException {
		InputStream input = null;
        Properties prop = new Properties();
		try {
			input = new FileInputStream("C:\\Users\\u21a49\\Desktop\\kafka_test\\123\\src\\main\\java\\Kafka_producer\\file.properties");
			prop.load(input);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		input.close();
			
		Path path = Paths.get("E:\\\\nikaza\\\\us_test");
		WatchService watchService =  path.getFileSystem().newWatchService();
		path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE);
		WatchKey watchKey = null;
		while (true) {
			System.out.println("true");
			ArrayList<String> files_list=new ArrayList<String>();
		    watchKey = watchService.poll(1, TimeUnit.MINUTES);
			    if(watchKey != null) {
			        watchKey.pollEvents().stream().forEach(event -> files_list.add("E:\\\\nikaza\\\\us_test\\\\"+event.context().toString()));
			    }
		    watchKey.reset();
			    for(String obj : files_list) {
			    	String topic = "avl2";
			        String key = "key1";
			        Producer<String, String> producer = new KafkaProducer<String, String>(prop);
			    	GZIPInputStream gzip = new GZIPInputStream(new FileInputStream(obj));
					BufferedReader br = new BufferedReader(new InputStreamReader(gzip));
					String content;
					System.out.println("sending the contents of"+obj);
						while ((content = br.readLine()) != null) {
						  	producer.send(new ProducerRecord<String, String>(topic, key, content));
							System.out.println(content.split(",")[0].toString());
						}
					br.close();
					gzip.close();
					System.out.println("Contents of "+obj+" sent successfully");
					producer.close();
				}
		}
	
	}
}