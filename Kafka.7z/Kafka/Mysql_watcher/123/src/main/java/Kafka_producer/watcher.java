package Kafka_producer;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPInputStream;

class watcher{
	public static void main(String[]args) throws IOException, InterruptedException {
		ArrayList<String> files_list=new ArrayList<String>();
		Path path = Paths.get("E:\\\\nikaza\\\\us_test");
		WatchService watchService =  path.getFileSystem().newWatchService();
		path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE);
		
		WatchKey watchKey = null;
		while (true) {
		    watchKey = watchService.poll(10, TimeUnit.MINUTES);
		    if(watchKey != null) {
		        watchKey.pollEvents().stream().forEach(event -> files_list.add("E:\\\\nikaza\\\\us_test\\\\"+event.context().toString()));
		    }
		    watchKey.reset();
		    for(String obj : files_list) {
		    	GZIPInputStream gzip = new GZIPInputStream(new FileInputStream(obj));
				BufferedReader br = new BufferedReader(new InputStreamReader(gzip));
				String content;
				System.out.println("=============================================================="+obj+"===========================================================================");
				while ((content = br.readLine()) != null) {
				  	  System.out.println(content);
				}
				System.out.println("===============================================================================================================================================================================");	
			}
		    files_list.clear();
		}
	
	}
}