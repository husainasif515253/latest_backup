import os
from kafka import KafkaProducer

producer = KafkaProducer(bootstrap_servers=['192.168.5.66:9092'], value_serializer=lambda x:x.encode('utf-8'))

dir = "/home/abcd/husain/datasets/"

files = os.listdir(dir)
for file in files:
	print("sending the contents of ", file)
	with open(dir+file, 'rb') as x:
		for line in x:
			producer.send('test',line.decode())

producer.close()
