import MySQLdb
from kafka import KafkaProducer

ts = 1549435940
while(True):
    producer = KafkaProducer(bootstrap_servers=['baremetal08.ibm.cloud:6667'],value_serializer=lambda x:x.encode('utf-8'))
    db = MySQLdb.connect("baremetal08.ibm.cloud","root","A43lB5Dm","Ericsson_Poc" )
    cursor = db.cursor()
    cursor.execute("SELECT IDENTIFIER,SERIAL,NODE,NODEALIAS,MANAGER, UNIX_TIMESTAMP(ts) FROM eg2 where UNIX_TIMESTAMP(ts) > "+str(ts))
    data = cursor.fetchall()
    if(len(data) != 0):
            for i in range(len(data)):
                    content = str(data[i][0])+"#"+str(data[i][1])+"#"+str(data[i][2])+"#"+str(data[i][3])+"#"+str(data[i][4])
                    producer.send('test', content)
                    ts = data[i][5]
    db.close()
    producer.close()