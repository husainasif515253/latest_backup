from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.clustering import KMeans, KMeansModel
from pyspark.ml.evaluation import ClusteringEvaluator

df = spark.readStream.format("kafka").option("kafka.bootstrap.servers", "192.168.5.72:9092").option("subscribe","test").option("auto.offset.reset", "earliest").load()

df = df.select("value", "offset")
split_col = split(df["value"], ",")

df = df.withColumn("Date/Time", split_col.getItem(0).cast(StringType()))
df = df.withColumn("Lat", split_col.getItem(1).cast(DoubleType()))
df = df.withColumn("lon", split_col.getItem(2).cast(DoubleType()))
df = df.withColumn("base", split_col.getItem(3).cast(StringType()))

#df = df.withColumn("Date/Time", unix_timestamp(df["Date/Time"], "MM/dd/yyyy HH:mm:ss").cast(DoubleType()).cast(TimestampType()))

df = df.select("Date/Time", "Lat", "lon", "base")


model = KMeansModel.load("file:///home/osboxes/Desktop/spark_realtime_ml/model/savemodel")

centers = model.clusterCenters()
print("Final Centers: ")
for center in centers:
    print(center)



featureCols = VectorAssembler(inputCols=["Lat","lon"], outputCol="features")
df2 = featureCols.transform(df)
categories = model.transform(df2)

res = categories.select("Date/Time", "Lat", "lon", "base", "prediction")

res.writeStream.outputMode("append").format("console").start()




