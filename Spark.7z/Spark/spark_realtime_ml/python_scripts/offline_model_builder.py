from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.clustering import KMeans
from pyspark.ml.evaluation import ClusteringEvaluator


schema = StructType([
		StructField("Date/Time", StringType(), True),
		StructField("Lat", DoubleType(), True),
		StructField("lon", DoubleType(), True),
		StructField("base", StringType(), True)	
	])

df = spark.read.format("csv").option("header", "true").schema(schema).load("file:///home/osboxes/Desktop/spark_realtime_ml/data/uber-raw-data-apr14.csv")

#df = df.withColumn("Date/Time", unix_timestamp(df["Date/Time"], "MM/dd/yyyy HH:mm:ss").cast(DoubleType()).cast(TimestampType()))


featureCols = VectorAssembler(inputCols=["Lat","lon"], outputCol="features")

df2 = featureCols.transform(df)

trainingData, testData = df2.randomSplit([0.7,0.3],5043)

kmeans = KMeans().setK(8).setFeaturesCol("features").setPredictionCol("prediction")
model = kmeans.fit(df2)

centers = model.clusterCenters()
print("Final Centers: ")
for center in centers:
    print(center)


categories = model.transform(testData)

categories.select(hour("Date/Time").alias("hour"), "prediction").groupBy("hour", "prediction").agg(count("prediction").alias("count")).orderBy(desc("count")).show()


model.write().overwrite().save("file:///home/osboxes/Desktop/spark_realtime_ml/model/savemodel")














# Evaluate clustering by computing Silhouette score
evaluator = ClusteringEvaluator()

silhouette = evaluator.evaluate(predictions)
print("Silhouette with squared euclidean distance = " + str(silhouette))

# Shows the result.








