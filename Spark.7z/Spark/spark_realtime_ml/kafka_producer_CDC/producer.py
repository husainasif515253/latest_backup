import MySQLdb
from kafka import KafkaProducer

ts = 1550039511
while(True):
    producer = KafkaProducer(bootstrap_servers=['192.168.5.72:9092'],value_serializer=lambda x:x.encode('utf-8'))
    db = MySQLdb.connect("localhost","debian-sys-maint","YquUrqzz91EU0QAs","spark" )
    cursor = db.cursor()
    cursor.execute("SELECT dt,lat,lon,base_data, UNIX_TIMESTAMP(ts) FROM eg2 where UNIX_TIMESTAMP(ts) > "+str(ts))
    data = cursor.fetchall()
    if(len(data) != 0):
            for i in range(len(data)):
                    content = str(data[i][0])+","+str(data[i][1])+","+str(data[i][2])+","+str(data[i][3])
                    producer.send('test', content)
                    ts = data[i][4]
    db.close()
    producer.close()
