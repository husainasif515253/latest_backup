#--packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.3.0
#--packages com.hortonworks:shc-core:1.1.1-2.1-s_2.11


from pyspark.sql.functions import split
from pyspark import SparkConf, SparkContext
from pyspark.sql.functions import explode
from pyspark.sql import SparkSession
from pyspark.sql.functions import split
from pyspark.sql import SQLContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import json
import happybase
from pyspark.sql import Row

df = spark.readStream.format('kafka').option('kafka.bootstrap.servers', 'sandbox-hdp.hortonworks.com:6667').option('subscribe','test').option("auto.offset.reset", "earliest").load()
z = df.selectExpr('CAST(key AS STRING)', 'CAST(value AS STRING)', 'offset')
y = z.select('offset', 'value')
split_col = split(y['value'], ',')
y = y.withColumn('id', split_col.getItem(0))
y = y.withColumn('datee', split_col.getItem(1))
y = y.withColumn('timee', split_col.getItem(2))
y = y.withColumn('cogt', split_col.getItem(3))
y = y.withColumn('pt08s1co', split_col.getItem(4))
y = y.withColumn('c6h6gt', split_col.getItem(5))
y = y.withColumn('pt08s2nmhc', split_col.getItem(6))
y = y.withColumn('noxgt', split_col.getItem(7))
y = y.withColumn('pt08s3nox', split_col.getItem(8))
y = y.withColumn('no2gt', split_col.getItem(9))
y = y.withColumn('pt08s4no2', split_col.getItem(10))
y = y.withColumn('pt08s5o3', split_col.getItem(11))
y = y.withColumn('t_data', split_col.getItem(12))
y = y.withColumn('RH_data', split_col.getItem(13))
y = y.withColumn('AH_data', split_col.getItem(14))
y = y.withColumn('ts', split_col.getItem(15))
y = y.withColumn('ts', y['ts'].cast('timestamp'))

windowedCounts = y.groupBy(window(y.ts, "1 hour", "5 minutes")).count()

windowedCounts.writeStream.queryName('example').outputMode('complete').format('console').trigger(continuous="1 second").start()



