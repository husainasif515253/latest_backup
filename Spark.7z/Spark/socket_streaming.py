from pyspark.sql.functions import split, explode

lines = spark.readStream.format('socket').option('host', 'localhost').option('port', 9999).load()

words = lines.select(explode(split(lines.value, " ")).alias("word"))

wordCount = words.groupBy("word").count()

query = wordCount.writeStream.outputMode('complete').format('console').start()

query.awaitTermination()