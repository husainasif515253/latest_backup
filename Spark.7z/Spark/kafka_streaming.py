#--packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.3.0

from pyspark.sql.functions import split
from pyspark import SparkConf, SparkContext
from pyspark.sql.functions import explode
from pyspark.sql import SparkSession
from pyspark.sql.functions import split
from pyspark.sql import SQLContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import json
#import happybase
from pyspark.sql import Row

df = spark.readStream.format('kafka').option('kafka.bootstrap.servers', 'sandbox-hdp.hortonworks.com:9092').option('subscribe','test').load()

df.writeStream.outputMode('append').format('console').start()

df1 = df.selectExpr('CAST(key AS STRING)', 'CAST(value AS STRING)', 'offset')

df1.writeStream.outputMode('append').format('console').start()

splitCol = split(df1['value'], '#')

df2 = df1.withColumn("InvoiceNo", splitCol.getItem(0)) 
df2 = df1.withColumn("StockCode", splitCol.getItem(1)) 
df2 = df1.withColumn("Description", splitCol.getItem(2)) 
df2 = df1.withColumn("Quantity", splitCol.getItem(3)) 
df2 = df1.withColumn("InvoiceDate", splitCol.getItem(4)) 
df2 = df1.withColumn("UnitPrice", splitCol.getItem(5)) 
df2 = df1.withColumn("CustomerID", splitCol.getItem(6)) 
df2 = df1.withColumn("Country", splitCol.getItem(7)) 

#df2 = df2.select("InvoiceNo", "StockCode", "Description", "Quantity", "InvoiceDate", "UnitPrice", "CustomerID", "Country")

df2.writeStream.outputMode('update').format('console').start()

df3 = df2.groupBy("country").count()

df3.writeStream.outputMode('update').format('console').start()
