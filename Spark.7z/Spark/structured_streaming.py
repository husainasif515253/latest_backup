#-------------------------------- import necessary modules --------------------------------

from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import explode
from pyspark.sql.functions import split
from pyspark.sql import SQLContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
from shapely.geometry.polygon import Polygon
from shapely.geometry import shape, Point, Polygon
import json

#-------------------------------- provide configurations for spark --------------------------------

conf = SparkConf().setMaster('yarn').setAppName('nikaza')
sc = SparkContext(conf = conf)
sqlContext = SQLContext(sc)
spark = SparkSession.builder.appName('nikaza').getOrCreate()
spark.conf.set("spark.sql.shuffle.partitions", 4)

#-------------------------------- define various paths of files --------------------------------

user_data_path = 'hdfs:/user/user1/husain/nikaza/test_data2/*.csv.gz'
polygon_data_path = '/home/user1/husain/nikaza/polygon_data/geojson_data.json'
#output_path = '/user/user1/husain/nikaza/output/structured_streaming'

#-------------------------------- streaming users data with specific schema --------------------------------

schema_data=StructType([StructField('app_id',StringType(),True),StructField('user_idfa',StringType(),True),StructField('user_idfa_limited',StringType(),True),StructField('device_os_type',StringType(),True),StructField('device_location_lat',DoubleType(),True),StructField('device_location_lng',DoubleType(),True),StructField('device_location_accuracy',StringType(),True),StructField('event_localtime',StringType(),True),StructField('event_time_utc',StringType(),True),StructField('event_type',StringType(),True),StructField('app_state',StringType(),True),StructField('application_id',StringType(),True),StructField('ip_address',StringType(),True)])

user_data = spark.readStream.schema(schema_data).option('header', True).option('maxFilesPerTrigger',3).csv(user_data_path)

#-------------------------------- reading polygon data --------------------------------

jdata = open(polygon_data_path,'r').read()
pp = json.loads(jdata)
feature_collection = pp['features']
polygon_objects = []
for x in range(len(feature_collection)):
	polygon_objects.append(Polygon(feature_collection[x]['geometry']['coordinates'][0]))

#-------------------------------- creating UDF for finding point in polygon --------------------------------

def pop(poly,longitude, latitude):
	return(polygon_objects[poly].contains(Point(longitude,latitude)))

point_in_poly = udf(pop)

#-------------------------------- apply udf for all the polygons on users data --------------------------------

for i in range(len(polygon_objects)):
	x = user_data.withColumn("polygon_id", lit(i))
	x = x.withColumn('status', point_in_poly(lit(i),x['device_location_lng'], x['device_location_lat']))
	x = x.select('*').where('status == true')
	x.writeStream.queryName(str('example'+str(i))).format('console').outputMode('update').start()
	

spark.streams.awaitAnyTermination()
